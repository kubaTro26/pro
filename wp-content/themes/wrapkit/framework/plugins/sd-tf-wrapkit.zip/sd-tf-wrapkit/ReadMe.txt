Author: Skat Design
Author URL: http://skat.tf
Version 1.0
Requires at least: 3.3
Tested up to: 3.6

== Description ==

An easy-to-use events custom post type plugin that helps you keep your items when switching themes.

== Support ==

* Being a free product, this plugin is distributed as-is without official support. Verified buyers of my themes however, will have access to support for this plugin in my support forums.

If you find a bug or have a suggestion please don't hesitate to contact me at: hello@skat.tf


== Features ==

* Creates an Events Custom Post Type
* Creates a custom taxonomy for the events items

== Installation ==

Follow the typical [WordPress plugin installation steps](http://codex.wordpress.org/Managing_Plugins#Installing_Plugins)